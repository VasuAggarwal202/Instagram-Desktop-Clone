/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package mycodes;
import java.sql.*;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import vmm.DBloader;

/**
 *
 * @author vasu
 */
public class user_unfriend extends javax.swing.JFrame {

    String email;
    
    public user_unfriend(String email) {
        
        initComponents();
        this.email=email;
         setSize(370, 669);
        
        setLocationRelativeTo(null);
        setVisible(true);
        getContentPane().setBackground(Color.BLACK);
        
        
        call();
        if (email.equals("follower"))
        {
            lb.setText("     Followers");
        } 
        else
        {
            lb.setText("     Following");
        }    
    }
    
    
    void call()
    {
        int x=10;
        int y=10;
        int count=0;
        if(email.equals("follower"))
        {
           
            try {
                
                ResultSet rs=DBloader.executeSql("select * from followers where follow_to='"+Global.email+"'");
                while(rs.next())
                {
                    count++;
                    String email1=rs.getString("follow_by");
                    int id=rs.getInt("follower_id");
                    user_design obj=new user_design();
                    obj.emaillabel.setText(email1);
                    ResultSet rs1=DBloader.executeSql("select * from users where email='"+email1+"'");
                    if(rs1.next())
                    {
                        String photo=rs1.getString("photo");
                        ImageIcon ic=new ImageIcon(photo);
                        Image ic1=ic.getImage().getScaledInstance(obj.photolabel.getWidth(), obj.photolabel.getHeight(), Image.SCALE_SMOOTH);
                        ImageIcon ic2=new ImageIcon(ic1);
                        obj.photolabel.setIcon(ic2);
                        obj.setBounds(x, y, 330, 160);
                        y+=175;
                        jp.add(obj);
                        jp.repaint();
                        obj.repaint();
                        obj.followbt.setText("Remove Follower");
                        obj.followbt.addActionListener(new ActionListener()
                        {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                
                                try {
                                    ResultSet rs=DBloader.executeSql("select * from followers where follower_id="+id+"");
                                    if(rs.next())
                                    {
                                        rs.deleteRow();
                                        dispose();
                                        user_unfriend obj=new user_unfriend("follower");
                                        obj.setVisible(true);
                                    }
                                } catch (Exception ex) {
                                    ex.printStackTrace();
                                }
                                
                            }
                            
                        }
                        );
                         obj.seeprofilebt.addActionListener(new ActionListener()
                        {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                               
                                other_user_profile obj5=new other_user_profile(email1);
                                
                            }
                            
                        }
                        );
                        
                        
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        else 
        {
           
            try {
                 ResultSet rs=DBloader.executeSql("select * from followers where follow_by='"+Global.email+"'");
                while(rs.next())
                {
                    count++;
                    String email1=rs.getString("follow_to");
                    int id=rs.getInt("follower_id");
                    user_design obj=new user_design();
                    obj.emaillabel.setText(email1);
                    ResultSet rs1=DBloader.executeSql("select * from users where email='"+email1+"'");
                    if(rs1.next())
                    {
                        String photo=rs1.getString("photo");
                        ImageIcon ic=new ImageIcon(photo);
                        Image ic1=ic.getImage().getScaledInstance(obj.photolabel.getWidth(), obj.photolabel.getHeight(), Image.SCALE_SMOOTH);
                        ImageIcon ic2=new ImageIcon(ic1);
                        obj.photolabel.setIcon(ic2);
                        obj.setBounds(x, y, 330, 160);
                        y+=175;
                        jp.add(obj);
                        jp.repaint();
                        obj.repaint();
                        obj.followbt.setText("Following");
                        obj.followbt.addActionListener(new ActionListener()
                        {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                                
                                try {
                                    ResultSet rs=DBloader.executeSql("select * from followers where follower_id="+id+"");
                                    if(rs.next())
                                    {
                                        rs.deleteRow();
                                        dispose();
                                        user_unfriend obj=new user_unfriend("following");
                                        obj.setVisible(true);
                                        
                                        
                                    }
                                } catch (Exception ex) {
                                    ex.printStackTrace();
                                }
                                
                            }
                            
                        }
                        );
                        
                        
                        obj.seeprofilebt.addActionListener(new ActionListener()
                        {
                            @Override
                            public void actionPerformed(ActionEvent e) {
                               
                                other_user_profile obj5=new other_user_profile(email1);
                                
                            }
                            
                        }
                        );
                        
                        
                        
                        
                    }
                }
            } catch (Exception ex) {
               ex.printStackTrace();
            }
        }
        jp.setPreferredSize(new Dimension(500,200*count));
    }
    
           
  

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jp = new javax.swing.JPanel();
        lb = new javax.swing.JLabel();
        backbt = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        jp.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jpLayout = new javax.swing.GroupLayout(jp);
        jp.setLayout(jpLayout);
        jpLayout.setHorizontalGroup(
            jpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 368, Short.MAX_VALUE)
        );
        jpLayout.setVerticalGroup(
            jpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 668, Short.MAX_VALUE)
        );

        jScrollPane1.setViewportView(jp);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(0, 60, 370, 610);

        lb.setFont(new java.awt.Font("Helvetica Neue", 1, 24)); // NOI18N
        lb.setForeground(new java.awt.Color(255, 255, 255));
        lb.setText("jLabel1");
        getContentPane().add(lb);
        lb.setBounds(90, 10, 260, 40);

        backbt.setFont(new java.awt.Font("Helvetica Neue", 0, 10)); // NOI18N
        backbt.setText("Go Back");
        backbt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                backbtActionPerformed(evt);
            }
        });
        getContentPane().add(backbt);
        backbt.setBounds(10, 20, 70, 19);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void backbtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_backbtActionPerformed
        // TODO add your handling code here:
        dispose();
        user_profile obj=new user_profile();
        
    }//GEN-LAST:event_backbtActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(user_unfriend.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(user_unfriend.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(user_unfriend.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(user_unfriend.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new user_unfriend("").setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton backbt;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel jp;
    private javax.swing.JLabel lb;
    // End of variables declaration//GEN-END:variables
}
