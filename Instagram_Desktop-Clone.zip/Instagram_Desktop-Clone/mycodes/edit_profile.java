/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package mycodes;

import java.awt.*;

import java.io.File;
import javax.swing.*;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import java.sql.*;

import vmm.DBloader;

/**
 *
 * @author vasu
 */
public class edit_profile extends javax.swing.JFrame {

    File ph;
    public edit_profile() {
        initComponents();
        
        setSize(964, 700);
        
        setLocationRelativeTo(null);
        setVisible(true);
        getContentPane().setBackground(Color.BLACK);
        
        user_details();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        nametf = new javax.swing.JTextField();
        contacttf = new javax.swing.JTextField();
        choosephotobt = new javax.swing.JButton();
        photo = new javax.swing.JLabel();
        rb1 = new javax.swing.JRadioButton();
        rb2 = new javax.swing.JRadioButton();
        rb3 = new javax.swing.JRadioButton();
        updatebt = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Helvetica Neue", 0, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Edit Profile");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(350, 20, 200, 70);

        jLabel2.setFont(new java.awt.Font("Helvetica Neue", 0, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Name");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(110, 120, 160, 50);

        jLabel3.setFont(new java.awt.Font("Helvetica Neue", 0, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Contact");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(110, 200, 150, 50);

        jLabel4.setFont(new java.awt.Font("Helvetica Neue", 0, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Gender");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(100, 300, 130, 50);
        getContentPane().add(nametf);
        nametf.setBounds(300, 120, 290, 50);
        getContentPane().add(contacttf);
        contacttf.setBounds(300, 200, 290, 50);

        choosephotobt.setFont(new java.awt.Font("Helvetica Neue", 0, 14)); // NOI18N
        choosephotobt.setText("Change Photo");
        choosephotobt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                choosephotobtActionPerformed(evt);
            }
        });
        getContentPane().add(choosephotobt);
        choosephotobt.setBounds(690, 410, 200, 40);
        getContentPane().add(photo);
        photo.setBounds(640, 80, 300, 300);

        buttonGroup1.add(rb1);
        rb1.setForeground(new java.awt.Color(255, 255, 255));
        rb1.setText("Male");
        getContentPane().add(rb1);
        rb1.setBounds(300, 320, 51, 21);

        buttonGroup1.add(rb2);
        rb2.setForeground(new java.awt.Color(255, 255, 255));
        rb2.setText("Female");
        getContentPane().add(rb2);
        rb2.setBounds(400, 320, 105, 21);

        buttonGroup1.add(rb3);
        rb3.setForeground(new java.awt.Color(255, 255, 255));
        rb3.setText("Others");
        getContentPane().add(rb3);
        rb3.setBounds(510, 310, 62, 30);

        updatebt.setFont(new java.awt.Font("Helvetica Neue", 1, 24)); // NOI18N
        updatebt.setText("Update");
        updatebt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updatebtActionPerformed(evt);
            }
        });
        getContentPane().add(updatebt);
        updatebt.setBounds(280, 530, 340, 90);

        jButton1.setText("Go Back");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(140, 560, 90, 40);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    void user_details()
    {    String name="";
         String contact="";
         String gender="";
         String photo1;
         try
        {
            ResultSet rs=DBloader.executeSql("select * from users where email='"+Global.email+"'");
            while(rs.next())
            {    
            name=rs.getString("name");
            contact=rs.getString("mobile");
            gender=rs.getString("gender");
            photo1=rs.getString("photo");
            ImageIcon ic5=new ImageIcon(photo1);
            Image ic6=ic5.getImage().getScaledInstance(photo.getWidth(), photo.getHeight(), Image.SCALE_SMOOTH);
            ImageIcon ic7=new ImageIcon(ic6);
            photo.setIcon(ic7);
            
            }
            nametf.setText(name);
            contacttf.setText(contact);
            if(gender.equals("Male"))
            {
                rb1.setSelected(true);
            }    
            else if(gender.equals("Female"))
            {
                rb2.setSelected(true);
            } 
             else if(gender.equals("Others"))
            {
                rb3.setSelected(true);
            } 
            
        }
         
         catch(Exception ex)
         {
             ex.printStackTrace();
         }  
       
    }
    
    
    private void choosephotobtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_choosephotobtActionPerformed
        // TODO add your handling code here:
        JFileChooser jfc=new JFileChooser();
        int ans=jfc.showOpenDialog(this);
        if(ans==JFileChooser.APPROVE_OPTION)
        {
           ph=jfc.getSelectedFile();
           ImageIcon ic=new ImageIcon(ph.getPath());
           Image ic1=ic.getImage().getScaledInstance(photo.getWidth(), photo.getHeight(), Image.SCALE_SMOOTH);
           ImageIcon ic2=new ImageIcon(ic1);
           photo.setIcon(ic2);
            
        }
    }//GEN-LAST:event_choosephotobtActionPerformed

    private void updatebtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updatebtActionPerformed
        // TODO add your handling code here:
        String name=nametf.getText();
        String contact=contacttf.getText();
        
        String gender="";
        if(rb1.isSelected())
        {
            gender="Male";
        }
        else if(rb2.isSelected())
        {
            gender="Female";
        }   
        else if(rb3.isSelected())
        {
            gender="Others";
        }    
        
        if(ph==null)
        {
            System.out.println("In If");
            String ans=MyClient.editprofilewithoutphotoselected(name,contact, gender);
            JOptionPane.showMessageDialog(this, ans);
            user_profile obj=new user_profile();
            dispose();
        }    
        else
        {    
            System.out.println("In Else");
            String ans=MyClient.editprofilewithphotoselected(name,contact, gender, ph);
            JOptionPane.showMessageDialog(this,ans);
            
            user_profile obj=new user_profile();
            dispose();
        }
    }//GEN-LAST:event_updatebtActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        user_profile obj=new user_profile();
            dispose();
        
                
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(edit_profile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(edit_profile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(edit_profile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(edit_profile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new edit_profile().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton choosephotobt;
    private javax.swing.JTextField contacttf;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JTextField nametf;
    private javax.swing.JLabel photo;
    private javax.swing.JRadioButton rb1;
    private javax.swing.JRadioButton rb2;
    private javax.swing.JRadioButton rb3;
    private javax.swing.JButton updatebt;
    // End of variables declaration//GEN-END:variables
}
