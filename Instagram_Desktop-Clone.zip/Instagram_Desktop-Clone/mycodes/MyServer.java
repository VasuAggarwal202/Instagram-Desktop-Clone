
package mycodes;

import com.vmm.JHTTPServer;
import static com.vmm.NanoHTTPD.HTTP_OK;
import java.io.File;
import java.io.IOException;
import java.util.Properties;
import java.sql.*;
import java.time.Instant;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;



import vmm.DBloader;

public class MyServer extends JHTTPServer {

    public MyServer(int portno) throws IOException 
    {
        super(portno);
        scheduleOldPicturesDeletion();  
    }

   @Override
    public Response serve(String uri, String method, Properties header, Properties parms, Properties files) {

        System.out.println("URI " + uri);

        if (uri.equals("/user_signup")) 
        {
           String ans="";
            String name=parms.getProperty("name");
            String email=parms.getProperty("email");
            String gender=parms.getProperty("gender");
            String password=parms.getProperty("password");
            String contact=parms.getProperty("contact");
            String photoname = saveFileOnServerWithRandomName(files, parms, "photo", "src/myuploads/");
            
            
            File folder = new File("src/myuploads/");
            File[] listofFiles = folder.listFiles();
            for (int i = 0; i < listofFiles.length; i++) {
                String name2 = listofFiles[i].getName();
                StringBuilder st = new StringBuilder(name2);
                File f = new File("src/myuploads/" + listofFiles[i].getName());
                if (st.charAt(0) == '\\') {
                    f.renameTo(new File("src/myuploads/" + st.deleteCharAt(0)));
                }

            }
            
             try 
            {
                ResultSet rs=DBloader.executeSql("select * from users where name='"+name+"' and email='"+email+"'");

                if(rs.next())
                {
                    ans="Name or Email Already Exists";
                }
                else
                {
                    ans="Signup Successfull";
                    rs.moveToInsertRow();
                    rs.updateString("name", name);
                    rs.updateString("email", email);
                    rs.updateString("gender", gender);
                    rs.updateString("password", password);
                    rs.updateString("mobile",contact );
                    rs.updateString("photo", "src/myuploads/" + photoname);
                    rs.insertRow();
                }
            } catch (Exception ex) 
            {
                ex.printStackTrace();
            }
            
            
           Response res=new Response(HTTP_OK, "text/plain", ans);
            return res;
        }
        
        
        
        else if (uri.equals("/user_Login"))
            {
                String ans="";
                String email=parms.getProperty("email");
                String password=parms.getProperty("password");
            
                
                
            try 
                {
                    ResultSet rs=DBloader.executeSql("select * from users where email='"+email+"' and password='"+password+"'");

                    if(rs.next())
                    {
                        ans="Login Successful";
                    }
                    else
                    {
                        ans="Incorrect Email or Password";
                    
                    }
                } 
                
                catch (Exception ex) 
            {
                ex.printStackTrace();
            }
            
            
           Response res=new Response(HTTP_OK, "text/plain", ans);
            return res;
                
                    
            } 
             
        
        
        else if (uri.equals("/all_users"))
            {
                String ans="";
                
               
               
            try 
                {
                      ResultSet rs=DBloader.executeSql("select * from users where email!='"+Global.email+"' ");
                    

                    while(rs.next())
                    {
                       String email=rs.getString("email");
                       String photo=rs.getString("photo");
                       String row=email+"$"+photo;
                       ans+=row+";;";
   
                    }
                   
                } 
                
                catch (Exception ex) 
            {
                ex.printStackTrace();
            }
            
            
           Response res=new Response(HTTP_OK, "text/plain", ans);
            return res;
                
                    
            } 
        
        
        
        
        
        else if (uri.equals("/addPost")) 
        {
           String ans="";
          
            String email=parms.getProperty("email");
            String caption =parms.getProperty("caption");
            String photoname = saveFileOnServerWithRandomName(files, parms, "photo", "src/myuploads/");
            
            
            File folder = new File("src/myuploads/");
            File[] listofFiles = folder.listFiles();
            for (int i = 0; i < listofFiles.length; i++) {
                String name2 = listofFiles[i].getName();
                StringBuilder st = new StringBuilder(name2);
                File f = new File("src/myuploads/" + listofFiles[i].getName());
                if (st.charAt(0) == '\\') {
                    f.renameTo(new File("src/myuploads/" + st.deleteCharAt(0)));
                }

            }
            
             try 
            {
                ResultSet rs=DBloader.executeSql("select * from posts");

               
                    ans="Post Added Successfully";
                    rs.moveToInsertRow();
                  
                    rs.updateString("email", email);
                  
                    rs.updateString("caption",caption );
                    rs.updateString("photo", "src/myuploads/" + photoname);
                    rs.insertRow();
                
            } 
             catch (Exception ex) 
            {
                ex.printStackTrace();
            }
            
            
           Response res=new Response(HTTP_OK, "text/plain", ans);
            return res;
        }
        
        
         else if (uri.equals("/show_post")) 
        {
           String ans="";
           String email=parms.getProperty("email");
           try
           {
                ResultSet rs2=DBloader.executeSql("select * from posts where email='"+email+"'");
                while(rs2.next())
                {
                    String photo=rs2.getString("photo");
                    String caption=rs2.getString("caption");
                    int postid=rs2.getInt("post_id");
                    
                    String row=photo+"$"+caption+"$"+postid;
                    ans+=row+";;";
                    
                }    
                    
                
           }
           catch(Exception ex)
           {
               ex.printStackTrace();
           }        
               
        
            
            
           Response res=new Response(HTTP_OK, "text/plain", ans);
            return res;
        }
         
         
         
         else if (uri.equals("/addStory")) 
        {
           String ans="";
          
            String email=parms.getProperty("email");
            String caption =parms.getProperty("caption");
            String photoname = saveFileOnServerWithRandomName(files, parms, "photo", "src/myuploads/");
            
            
            File folder = new File("src/myuploads/");
            File[] listofFiles = folder.listFiles();
            for (int i = 0; i < listofFiles.length; i++) {
                String name2 = listofFiles[i].getName();
                StringBuilder st = new StringBuilder(name2);
                File f = new File("src/myuploads/" + listofFiles[i].getName());
                if (st.charAt(0) == '\\') {
                    f.renameTo(new File("src/myuploads/" + st.deleteCharAt(0)));
                }

            }
            
             try 
            {
                ResultSet rs=DBloader.executeSql("select * from story");

               
                    ans="Story Added Successfully";
                    rs.moveToInsertRow();
                  
                    rs.updateString("email", email);
                  
                    rs.updateString("caption",caption );
                    rs.updateString("photo", "src/myuploads/" + photoname);
                    rs.insertRow();
                
            } 
             catch (Exception ex) 
            {
                ex.printStackTrace();
            }
            
            
           Response res=new Response(HTTP_OK, "text/plain", ans);
            return res;
        }
         
         
         
         
         
         else if (uri.equals("/show_story")) 
        {
           String ans="";
           String email=parms.getProperty("email");
           try
           {
                ResultSet rs2=DBloader.executeSql("select * from story where email='"+email+"'");
                while(rs2.next())
                {
                    String photo=rs2.getString("photo");
                    String caption=rs2.getString("caption");
                    
                    
                    String row=photo+"$"+caption;
                    ans+=row+";;";
                    
                }    
                    
                
           }
           catch(Exception ex)
           {
               ex.printStackTrace();
           }        
               
        
            
            
           Response res=new Response(HTTP_OK, "text/plain", ans);
            return res;
        }
         
         
         
        
        else if (uri.equals("/user_posts")) 
        {
           String ans="";
          
           try
           {
                ResultSet rs2=DBloader.executeSql("select * from posts where email='"+Global.email+"'");
                while(rs2.next())
                {
                    String photo=rs2.getString("photo");
                    String caption=rs2.getString("caption");
                    int id =rs2.getInt("post_id");
                    
                    
                    String row=photo+"$"+caption+"$"+id;
                    ans+=row+";;";
                    
                }    
                    
                
           }
           catch(Exception ex)
           {
               ex.printStackTrace();
           }        
               
        
         
            
           Response res=new Response(HTTP_OK, "text/plain", ans);
            return res;
        }
        
        
        
        else if (uri.equals("/other_user_posts")) 
        {
           String ans="";
           String email=parms.getProperty("email");
           
           try
           {
                ResultSet rs2=DBloader.executeSql("select * from posts where email='"+email+"'");
                while(rs2.next())
                {
                    String photo=rs2.getString("photo");
                    String caption=rs2.getString("caption");
                    int id =rs2.getInt("post_id");
                    
                    
                    String row=photo+"$"+caption+"$"+id;
                    ans+=row+";;";
                    
                }    
                    
                
           }
           catch(Exception ex)
           {
               ex.printStackTrace();
           }        
               
        
         
            
           Response res=new Response(HTTP_OK, "text/plain", ans);
            return res;
        }
        
        
        
        
        
       
        
        else if (uri.equals("/editprofilewithphotoselected")) 
        {
           String ans="";
            String name=parms.getProperty("name");
            
            String gender=parms.getProperty("gender");
           
            String contact=parms.getProperty("contact");
            String photoname = saveFileOnServerWithRandomName(files, parms, "photo", "src/myuploads/");
            
            
            File folder = new File("src/myuploads/");
            File[] listofFiles = folder.listFiles();
            for (int i = 0; i < listofFiles.length; i++) {
                String name2 = listofFiles[i].getName();
                StringBuilder st = new StringBuilder(name2);
                File f = new File("src/myuploads/" + listofFiles[i].getName());
                if (st.charAt(0) == '\\') {
                    f.renameTo(new File("src/myuploads/" + st.deleteCharAt(0)));
                }

            }
            
             try 
            {
                ResultSet rs=DBloader.executeSql("select * from users where email='"+Global.email+"' ");

                
                if(rs.next())
                {
                    ans="Update Successfull";
                    
                    rs.updateString("name", name);
                 
                    rs.updateString("gender", gender);
                   
                    rs.updateString("mobile",contact );
                    rs.updateString("photo", "src/myuploads/" + photoname);
                    rs.updateRow();
                }
            } catch (Exception ex) 
            {
                ex.printStackTrace();
            }
            
            
           Response res=new Response(HTTP_OK, "text/plain", ans);
            return res;
        }
        
        
        
        else if (uri.equals("/editprofilewithoutphotoselected")) 
        {
           String ans="";
            String name=parms.getProperty("name");
            
            String gender=parms.getProperty("gender");
           
            String contact=parms.getProperty("contact");
           
            
           
            
             try 
            {
                ResultSet rs=DBloader.executeSql("select * from users where email='"+Global.email+"' ");

                
                if(rs.next())
                {
                    ans="Update Successfull";
                    
                    rs.updateString("name", name);
                 
                    rs.updateString("gender", gender);
                   
                    rs.updateString("mobile",contact );
                   
                    rs.updateRow();
                }
            } 
            
            catch (Exception ex) 
            {
                ex.printStackTrace();
            }
            
            
           Response res=new Response(HTTP_OK, "text/plain", ans);
            return res;
        }
        
        
        
        
        else 
        {
            Response res = new Response(HTTP_OK, "text/plain", "Invalid URL");

            return res;
        }
}
    
    public void deleteOldPictures() {
        String dbURL = "jdbc:mysql://localhost:3306/Instagram_Clone";
        String dbUser = "root";
        String dbPassword = "System123@";
        String query = "DELETE FROM story WHERE date_time < ?";
        
        try (Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPassword);
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            Timestamp cutoffTime = Timestamp.from(Instant.now().minusSeconds(24 * 60 * 60));
            pstmt.setTimestamp(1, cutoffTime);

            int rowsDeleted = pstmt.executeUpdate();
            System.out.println(rowsDeleted + " old pictures deleted.");

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

     public void scheduleOldPicturesDeletion() {
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
        Runnable task = this::deleteOldPictures;
        scheduler.scheduleAtFixedRate(task, 0, 1, TimeUnit.HOURS); // Initial delay of 0 means it runs immediately
    }
    
    
}