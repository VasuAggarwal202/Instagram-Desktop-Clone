
package mycodes;

import java.awt.Color;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;


public class Login extends javax.swing.JFrame {

    /**
     * Creates new form Login
     */
    public Login() 
    {
        initComponents();
        
        setSize(583, 540);
        setLocationRelativeTo(null);
        
        setVisible(true);
        getContentPane().setBackground(Color.BLACK);
        visiblepassword.setVisible(false);
        
        ImageIcon ic5=new ImageIcon("/Users/vasu/Desktop/photos/images.png");
       Image ic6=ic5.getImage().getScaledInstance(showpasswordbt.getWidth(), showpasswordbt.getHeight(), Image.SCALE_SMOOTH);
       ImageIcon ic7=new ImageIcon(ic6);
       showpasswordbt.setIcon(ic7);
        
        
       //ImageIcon ic5=new ImageIcon("/Users/vasu/Desktop/");
       //Image ic6=ic5.getImage().getScaledInstance(logo.getWidth(), logo.getHeight(), Image.SCALE_SMOOTH);
       //ImageIcon ic7=new ImageIcon(ic6);
       //logo.setIcon(ic7);
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        emailtf = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        passwordtf = new javax.swing.JPasswordField();
        loginbt = new javax.swing.JButton();
        logo = new javax.swing.JLabel();
        lb = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        visiblepassword = new javax.swing.JTextField();
        showpasswordbt = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Helvetica Neue", 1, 60)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 0, 153));
        jLabel1.setText("Instagram");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(150, 10, 290, 110);

        jLabel3.setFont(new java.awt.Font("Helvetica Neue", 0, 30)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Email");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(90, 160, 100, 40);
        getContentPane().add(emailtf);
        emailtf.setBounds(220, 160, 310, 40);

        jLabel4.setFont(new java.awt.Font("Helvetica Neue", 0, 30)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Password");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(60, 230, 140, 30);

        passwordtf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passwordtfActionPerformed(evt);
            }
        });
        getContentPane().add(passwordtf);
        passwordtf.setBounds(220, 230, 310, 40);

        loginbt.setBackground(new java.awt.Color(0, 0, 204));
        loginbt.setFont(new java.awt.Font("Helvetica Neue", 0, 36)); // NOI18N
        loginbt.setForeground(new java.awt.Color(255, 255, 255));
        loginbt.setText("Login");
        loginbt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginbtActionPerformed(evt);
            }
        });
        getContentPane().add(loginbt);
        loginbt.setBounds(100, 340, 370, 60);

        logo.setText("jLabel2");
        getContentPane().add(logo);
        logo.setBounds(0, 10, 150, 130);

        lb.setFont(new java.awt.Font("Helvetica Neue", 1, 18)); // NOI18N
        lb.setForeground(new java.awt.Color(0, 51, 204));
        lb.setText("Forgot Password? Send OTP");
        lb.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbMouseClicked(evt);
            }
        });
        getContentPane().add(lb);
        lb.setBounds(150, 420, 260, 40);

        jLabel6.setFont(new java.awt.Font("Helvetica Neue", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 51, 204));
        jLabel6.setText("Dont have an account? Signup");
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });
        getContentPane().add(jLabel6);
        jLabel6.setBounds(150, 460, 270, 30);
        getContentPane().add(visiblepassword);
        visiblepassword.setBounds(220, 230, 310, 40);

        showpasswordbt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showpasswordbtActionPerformed(evt);
            }
        });
        getContentPane().add(showpasswordbt);
        showpasswordbt.setBounds(540, 240, 30, 23);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void loginbtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginbtActionPerformed
        // TODO add your handling code here:
        String email =emailtf.getText();
        String password="";
        if(passwordtf.isVisible())
        {    
          password=passwordtf.getText();
        }
        
        else if(visiblepassword.isVisible())
        {
            password=visiblepassword.getText();
        }
        
         String ans=MyClient.userLogin(email, password);
         if(ans.equals("Login Successful"))
         {
             Global.email=email;
             
             Homepage obj=new Homepage();
             dispose();
         } 
         else
         {
             JOptionPane.showMessageDialog(this,ans);
         }    
        
        
    }//GEN-LAST:event_loginbtActionPerformed

    
     
    
    
    
    
    
    private void lbMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbMouseClicked
        // TODO add your handling code here:
        forgot_password obj=new forgot_password();
        dispose();
        
    }//GEN-LAST:event_lbMouseClicked

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
        // TODO add your handling code here:
        
         UserSignup obj = new UserSignup();
         dispose();
    }//GEN-LAST:event_jLabel6MouseClicked

    private void passwordtfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passwordtfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passwordtfActionPerformed

    private void showpasswordbtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showpasswordbtActionPerformed
        // TODO add your handling code here:
        
        if(passwordtf.isVisible())
        {    
         String pass=passwordtf.getText();  
         passwordtf.setVisible(false);
         visiblepassword.setText(pass);
         visiblepassword.setVisible(true);
        } 
        else
        {
            String pass=visiblepassword.getText();  
         visiblepassword.setVisible(false);
         passwordtf.setText(pass);
         passwordtf.setVisible(true);
        }    
        
    }//GEN-LAST:event_showpasswordbtActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField emailtf;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel lb;
    private javax.swing.JButton loginbt;
    private javax.swing.JLabel logo;
    private javax.swing.JPasswordField passwordtf;
    private javax.swing.JButton showpasswordbt;
    private javax.swing.JTextField visiblepassword;
    // End of variables declaration//GEN-END:variables
}
