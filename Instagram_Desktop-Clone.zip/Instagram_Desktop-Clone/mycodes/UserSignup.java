
package mycodes;

import java.awt.Color;
import java.awt.Image;
import java.io.File;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;


public class UserSignup extends javax.swing.JFrame {

    
    File ph;
    
    public UserSignup() {
        initComponents();
        
        setSize(1000,720);
        setLocationRelativeTo(null);
        setVisible(true);
        getContentPane().setBackground(Color.BLACK);
        ImageIcon ic5=new ImageIcon("/Users/vasu/Desktop/photos/dp.jpg");
        Image ic6=ic5.getImage().getScaledInstance(photo.getWidth(), photo.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon ic7=new ImageIcon(ic6);
        photo.setIcon(ic7);
    }



    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        usernametf = new javax.swing.JTextField();
        emailtf = new javax.swing.JTextField();
        contacttf = new javax.swing.JTextField();
        photo = new javax.swing.JLabel();
        signupbt = new javax.swing.JButton();
        choosephotobt = new javax.swing.JButton();
        passwordtf = new javax.swing.JPasswordField();
        jLabel7 = new javax.swing.JLabel();
        rb1 = new javax.swing.JRadioButton();
        rb2 = new javax.swing.JRadioButton();
        rb3 = new javax.swing.JRadioButton();
        loginbt = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Helvetica Neue", 1, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("User Signup");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(350, 10, 320, 70);

        jLabel2.setFont(new java.awt.Font("Helvetica Neue", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Username");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(200, 110, 140, 40);

        jLabel3.setFont(new java.awt.Font("Helvetica Neue", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Email");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(210, 190, 100, 40);

        jLabel4.setFont(new java.awt.Font("Helvetica Neue", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Password");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(200, 280, 140, 30);

        jLabel5.setFont(new java.awt.Font("Helvetica Neue", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Gender");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(200, 430, 84, 30);
        getContentPane().add(usernametf);
        usernametf.setBounds(390, 110, 250, 40);
        getContentPane().add(emailtf);
        emailtf.setBounds(390, 190, 250, 40);
        getContentPane().add(contacttf);
        contacttf.setBounds(390, 340, 250, 40);
        getContentPane().add(photo);
        photo.setBounds(710, 100, 250, 240);

        signupbt.setFont(new java.awt.Font("Helvetica Neue", 1, 36)); // NOI18N
        signupbt.setText("Signup");
        signupbt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                signupbtActionPerformed(evt);
            }
        });
        getContentPane().add(signupbt);
        signupbt.setBounds(360, 510, 310, 80);

        choosephotobt.setFont(new java.awt.Font("Helvetica Neue", 0, 18)); // NOI18N
        choosephotobt.setText("Choose Photo");
        choosephotobt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                choosephotobtActionPerformed(evt);
            }
        });
        getContentPane().add(choosephotobt);
        choosephotobt.setBounds(740, 370, 190, 50);
        getContentPane().add(passwordtf);
        passwordtf.setBounds(390, 270, 250, 40);

        jLabel7.setFont(new java.awt.Font("Helvetica Neue", 1, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Contact");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(200, 350, 110, 30);

        buttonGroup1.add(rb1);
        rb1.setFont(new java.awt.Font("Helvetica Neue", 0, 18)); // NOI18N
        rb1.setForeground(new java.awt.Color(255, 255, 255));
        rb1.setText("Male");
        getContentPane().add(rb1);
        rb1.setBounds(390, 430, 70, 27);

        buttonGroup1.add(rb2);
        rb2.setFont(new java.awt.Font("Helvetica Neue", 0, 18)); // NOI18N
        rb2.setForeground(new java.awt.Color(255, 255, 255));
        rb2.setText("Female");
        getContentPane().add(rb2);
        rb2.setBounds(490, 430, 90, 27);

        buttonGroup1.add(rb3);
        rb3.setFont(new java.awt.Font("Helvetica Neue", 0, 18)); // NOI18N
        rb3.setForeground(new java.awt.Color(255, 255, 255));
        rb3.setText("Others");
        getContentPane().add(rb3);
        rb3.setBounds(600, 430, 78, 30);

        loginbt.setFont(new java.awt.Font("Helvetica Neue", 1, 36)); // NOI18N
        loginbt.setText("Login");
        loginbt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginbtActionPerformed(evt);
            }
        });
        getContentPane().add(loginbt);
        loginbt.setBounds(400, 610, 230, 60);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void choosephotobtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_choosephotobtActionPerformed
        // TODO add your handling code here:
        JFileChooser jfc=new JFileChooser();
        int ans=jfc.showOpenDialog(this);
        if(ans==JFileChooser.APPROVE_OPTION)
        {
           ph=jfc.getSelectedFile();
            ImageIcon ic=new ImageIcon(ph.getPath());
            Image ic1=ic.getImage().getScaledInstance(photo.getWidth(), photo.getHeight(), Image.SCALE_SMOOTH);
            ImageIcon ic2=new ImageIcon(ic1);
            photo.setIcon(ic2);
        }
    }//GEN-LAST:event_choosephotobtActionPerformed

    private void signupbtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_signupbtActionPerformed
        // TODO add your handling code here:
        
        
        
        String name=usernametf.getText();
        String email=emailtf.getText();
        String password=passwordtf.getText();
        String contact=contacttf.getText();
        
        String gender="";
        if(rb1.isSelected())
        {
            gender="Male";
        }
        else if(rb2.isSelected())
        {
            gender="Female";
        }   
        else if(rb3.isSelected())
        {
            gender="Others";
        }
        
        if(name.isEmpty()||email.isEmpty()||password.isEmpty()||contact.isEmpty()||gender.isEmpty()||ph==null)
        {
             JOptionPane.showMessageDialog(this, "Please Fill All fields and choose photo if not choosen");
        }    
        else
        {    
        String ans=MyClient.userSignup(name, email, password, contact, gender, ph);
        JOptionPane.showMessageDialog(this, ans);
        }
        
        
        
    }//GEN-LAST:event_signupbtActionPerformed

    private void loginbtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginbtActionPerformed
        // TODO add your handling code here:
        Login obj=new Login();
        dispose();
    }//GEN-LAST:event_loginbtActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UserSignup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UserSignup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UserSignup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UserSignup.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UserSignup().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton choosephotobt;
    private javax.swing.JTextField contacttf;
    private javax.swing.JTextField emailtf;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JButton loginbt;
    private javax.swing.JPasswordField passwordtf;
    private javax.swing.JLabel photo;
    private javax.swing.JRadioButton rb1;
    private javax.swing.JRadioButton rb2;
    private javax.swing.JRadioButton rb3;
    private javax.swing.JButton signupbt;
    private javax.swing.JTextField usernametf;
    // End of variables declaration//GEN-END:variables
}
