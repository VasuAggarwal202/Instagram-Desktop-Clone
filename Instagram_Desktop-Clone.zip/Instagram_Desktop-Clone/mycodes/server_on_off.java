
package mycodes;

import java.awt.Color;
import javax.swing.JOptionPane;


public class server_on_off extends javax.swing.JFrame {

    
    MyServer obj;
    public server_on_off() {
        initComponents();
        
        setSize(690, 500);
        setLocationRelativeTo(null);
        setVisible(true);
         getContentPane().setBackground(Color.BLACK);
        
    }

  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        loginbt = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        serveroffbt = new javax.swing.JToggleButton();
        serveronbt = new javax.swing.JToggleButton();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        loginbt.setFont(new java.awt.Font("Helvetica Neue", 3, 48)); // NOI18N
        loginbt.setText("Login");
        loginbt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginbtActionPerformed(evt);
            }
        });
        getContentPane().add(loginbt);
        loginbt.setBounds(150, 350, 380, 90);

        jLabel1.setFont(new java.awt.Font("Helvetica Neue", 0, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Turn Server ON/OFF");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(170, 80, 400, 110);

        buttonGroup1.add(serveroffbt);
        serveroffbt.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        serveroffbt.setText("Server OFF");
        serveroffbt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                serveroffbtActionPerformed(evt);
            }
        });
        getContentPane().add(serveroffbt);
        serveroffbt.setBounds(230, 240, 220, 50);

        buttonGroup1.add(serveronbt);
        serveronbt.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        serveronbt.setText("Server ON");
        serveronbt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                serveronbtActionPerformed(evt);
            }
        });
        getContentPane().add(serveronbt);
        serveronbt.setBounds(230, 180, 220, 50);

        jLabel3.setFont(new java.awt.Font("Helvetica Neue", 1, 60)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(153, 0, 153));
        jLabel3.setText("INSTAGRAM");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(160, 10, 420, 90);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void loginbtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginbtActionPerformed
       if(serveronbt.isSelected())
       {    
       Login obj=new Login();
       dispose();
       }
       else
       {
           JOptionPane.showMessageDialog(this,"Turn Server ON");
       }    
    }//GEN-LAST:event_loginbtActionPerformed

    private void serveroffbtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_serveroffbtActionPerformed
        // TODO add your handling code here:
        obj.shutdown();
        jLabel1.setText("       Server is OFF");
    }//GEN-LAST:event_serveroffbtActionPerformed

    private void serveronbtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_serveronbtActionPerformed
        // TODO add your handling code here:
        
          try{
            obj=new MyServer(9000);
            jLabel1.setText("       Server is On");

        }
        catch(Exception ex)
        {
            ex.printStackTrace();

        }
    }//GEN-LAST:event_serveronbtActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(server_on_off.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(server_on_off.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(server_on_off.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(server_on_off.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new server_on_off().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JButton loginbt;
    private javax.swing.JToggleButton serveroffbt;
    private javax.swing.JToggleButton serveronbt;
    // End of variables declaration//GEN-END:variables
}
