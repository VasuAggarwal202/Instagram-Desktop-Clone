/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package mycodes;

import java.awt.Color;
import java.awt.Image;
import java.sql.ResultSet;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import vmm.DBloader;

/**
 *
 * @author vasu
 */
public class delete_post extends javax.swing.JFrame {

    /**
     * Creates new form delete_post
     */
    int id;
    public delete_post(int id) 
    {
        initComponents();
        this.id=id;
        setSize(627,700);
        setLocationRelativeTo(null);
        setVisible(true);
        getContentPane().setBackground(Color.BLACK);
        call();
    }

    void call()
    {
        try
        {
           ResultSet rs=DBloader.executeSql("select * from posts where post_id='"+id+"'");  
           while(rs.next())
           {
               String photo=rs.getString("photo");
               ImageIcon ic5=new ImageIcon(photo);
               Image ic6=ic5.getImage().getScaledInstance(photolb.getWidth(), photolb.getHeight(), Image.SCALE_SMOOTH);
               ImageIcon ic7=new ImageIcon(ic6);
               photolb.setIcon(ic7);
               
           }    
        }   
        catch(Exception ex)
        {
            ex.printStackTrace();
        }    
    }        
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        photolb = new javax.swing.JLabel();
        deletebt = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        photolb.setText("jLabel1");
        getContentPane().add(photolb);
        photolb.setBounds(10, 10, 600, 550);

        deletebt.setFont(new java.awt.Font("Helvetica Neue", 1, 18)); // NOI18N
        deletebt.setText("Delete Post");
        deletebt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletebtActionPerformed(evt);
            }
        });
        getContentPane().add(deletebt);
        deletebt.setBounds(200, 600, 210, 50);

        jButton1.setText("Go Back");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(80, 610, 90, 30);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void deletebtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletebtActionPerformed
        // TODO add your handling code here:
       
        
        int ans = JOptionPane.showConfirmDialog(this,"Are you Sure u want to Delete post ??","Delete Confirmation",JOptionPane.YES_NO_OPTION); 
            
            if(ans==JOptionPane.YES_OPTION)
            {
                
                try
                {
                   ResultSet rs=DBloader.executeSql("select * from posts where post_id='"+id+"'");  
                   while(rs.next())
                   {
                       rs.deleteRow();
                       JOptionPane.showMessageDialog(this,"Post Deleted");
                       dispose();
                       user_profile obj=new user_profile();
                       
                   }    
                }   
                catch(Exception ex)
                {
                    ex.printStackTrace();
                }


                 dispose();
                
            }
        
      
    }//GEN-LAST:event_deletebtActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        dispose();
        user_profile obj=new user_profile();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(delete_post.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(delete_post.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(delete_post.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(delete_post.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new delete_post(1).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton deletebt;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel photolb;
    // End of variables declaration//GEN-END:variables
}
