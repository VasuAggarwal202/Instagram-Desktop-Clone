
package mycodes;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import java.sql.ResultSet;
import java.util.StringTokenizer;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.plaf.synth.ColorType;
import vmm.DBloader;

public class user_profile extends javax.swing.JFrame {

    /**
     * Creates new form user_profile
     */
    public user_profile() {
        initComponents();
        setSize(964, 700);
        
        setLocationRelativeTo(null);
        setVisible(true);
        getContentPane().setBackground(Color.BLACK);
        
        user_post();
        user_details();
  
    }
    
    void user_post()
    {
        String ans = MyClient.user_posts();
        System.out.println(ans);
        
        int count=0;
        int x=30;
        int y=30;
        jp.removeAll();
        StringTokenizer st=new StringTokenizer(ans, ";;");
        int token=st.countTokens();
        while(st.hasMoreTokens())
        {
            StringTokenizer st2=new StringTokenizer(st.nextToken(), "$");
            String photo=st2.nextToken();
            String caption=st2.nextToken();
            int id=Integer.parseInt(st2.nextToken());
            System.out.println(photo+",  ,"+caption);
            profile_post obj=new profile_post();
            
            
             obj.photo.addMouseListener(new MouseAdapter()
                        {
                                @Override
                                public void mouseClicked(MouseEvent e)
                                {
                                    delete_post obj=new delete_post(id);
                                    dispose();
                                    
                                }
                        }
                        );
            
            
              try 
              {
                  ResultSet rs=DBloader.executeSql("select * from likepost where post_id="+id+"");

                    while(rs.next())
                    {
                        count++;
                    }
              } 
              
              catch (Exception ex) 
              {
                ex.printStackTrace();
              }
              
            obj.like.setText("Likes "+count);
            ImageIcon ic=new ImageIcon(photo);
            Image ic1=ic.getImage().getScaledInstance(obj.photo.getWidth(), obj.photo.getHeight(), Image.SCALE_SMOOTH);
            ImageIcon ic2=new ImageIcon(ic1);
             obj.photo.setIcon(ic2);
            obj.setBounds(x, y, 270, 270);
            if(x<=600)
            {
                x+=290;
          
            }
            else
            {
                x=30;
                y+=290;
    
            }  
              
            count=0;  
            jp.add(obj);
            jp.repaint();
            obj.repaint();
            jp.revalidate();
        }
        jp.setPreferredSize(new Dimension(620,(200*token)/1));
    }    



    void user_details()    
    {   int followingcount=0;
        int followerscount=0; 
        try
        {
            ResultSet rs=DBloader.executeSql("select * from users where email='"+Global.email+"'");
            while(rs.next())
            {    
            String photo=rs.getString("photo");
            ImageIcon ic=new ImageIcon(photo);
            Image ic1=ic.getImage().getScaledInstance(userphoto.getWidth(), userphoto.getHeight(), Image.SCALE_SMOOTH);
            ImageIcon ic2=new ImageIcon(ic1);
            userphoto.setIcon(ic2);
            }
            useremail.setText(Global.email);
            
            ResultSet rs1=DBloader.executeSql("select * from followers where follow_by='"+Global.email+"'");
            while(rs1.next())
            {
                followingcount++;
            } 
            followinglb.setText(""+followingcount);
            
            ResultSet rs2=DBloader.executeSql("select * from followers where follow_to='"+Global.email+"'");
            while(rs2.next())
            {
                followerscount++;
            } 
            followerslb.setText(""+followerscount);
            
            
        } 
        catch(Exception ex)
        {
            ex.printStackTrace();
        }        
    }       
    
    

    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jp = new javax.swing.JPanel();
        userphoto = new javax.swing.JLabel();
        useremail = new javax.swing.JLabel();
        followerslb = new javax.swing.JLabel();
        followinglb = new javax.swing.JLabel();
        followersbt = new javax.swing.JButton();
        followingbt = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        jp.setBackground(new java.awt.Color(0, 0, 0));

        javax.swing.GroupLayout jpLayout = new javax.swing.GroupLayout(jp);
        jp.setLayout(jpLayout);
        jpLayout.setHorizontalGroup(
            jpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 938, Short.MAX_VALUE)
        );
        jpLayout.setVerticalGroup(
            jpLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 458, Short.MAX_VALUE)
        );

        jScrollPane1.setViewportView(jp);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(10, 185, 940, 460);

        userphoto.setText("jLabel1");
        getContentPane().add(userphoto);
        userphoto.setBounds(20, 10, 170, 160);

        useremail.setFont(new java.awt.Font("Helvetica Neue", 1, 24)); // NOI18N
        useremail.setForeground(new java.awt.Color(255, 255, 255));
        getContentPane().add(useremail);
        useremail.setBounds(200, 20, 340, 50);

        followerslb.setFont(new java.awt.Font("Helvetica Neue", 1, 18)); // NOI18N
        followerslb.setForeground(new java.awt.Color(255, 255, 255));
        followerslb.setText("jLabel3");
        getContentPane().add(followerslb);
        followerslb.setBounds(310, 90, 50, 30);

        followinglb.setFont(new java.awt.Font("Helvetica Neue", 1, 18)); // NOI18N
        followinglb.setForeground(new java.awt.Color(255, 255, 255));
        followinglb.setText("jLabel4");
        getContentPane().add(followinglb);
        followinglb.setBounds(630, 90, 50, 30);

        followersbt.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        followersbt.setText("Followers");
        followersbt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                followersbtActionPerformed(evt);
            }
        });
        getContentPane().add(followersbt);
        followersbt.setBounds(220, 130, 200, 40);

        followingbt.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        followingbt.setText("Following");
        followingbt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                followingbtActionPerformed(evt);
            }
        });
        getContentPane().add(followingbt);
        followingbt.setBounds(550, 130, 190, 40);

        jButton1.setText("Edit Profile");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(730, 30, 200, 40);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void followersbtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_followersbtActionPerformed
        // TODO add your handling code here:
        user_unfriend obj=new user_unfriend("follower");
        dispose();
    }//GEN-LAST:event_followersbtActionPerformed

    private void followingbtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_followingbtActionPerformed
        // TODO add your handling code here:
        user_unfriend obj=new user_unfriend("following");
        dispose();
    }//GEN-LAST:event_followingbtActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        edit_profile obj=new  edit_profile();
        dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(user_profile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(user_profile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(user_profile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(user_profile.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new user_profile().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton followersbt;
    private javax.swing.JLabel followerslb;
    private javax.swing.JButton followingbt;
    private javax.swing.JLabel followinglb;
    private javax.swing.JButton jButton1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPanel jp;
    private javax.swing.JLabel useremail;
    private javax.swing.JLabel userphoto;
    // End of variables declaration//GEN-END:variables
}
