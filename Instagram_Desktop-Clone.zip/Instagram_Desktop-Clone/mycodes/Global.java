
package mycodes;


public class Global 
{
    public static String email ="";

}
