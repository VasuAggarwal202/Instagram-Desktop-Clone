
package mycodes;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.util.StringTokenizer;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import vmm.DBloader;

public class Homepage extends javax.swing.JFrame {

    
    public Homepage() {
        initComponents();
        
        all_users();
        show_post();
        show_story();
                
        welcomelb.setText(Global.email);
                
        
        setSize(1440,857);
        setLocationRelativeTo(null);
        setVisible(true);
    }
    
    void show_story()
    {
         int x=10;
        int y=20;
        int x1=10;
        int y1=85;

        
            try
            {
                ResultSet rs = DBloader.executeSql("select * from followers where follow_by='"+Global.email+"'");
                while(rs.next())
                {
                    String email=rs.getString("follow_to");
                    String ans=MyClient.show_story(email);
                    StringTokenizer st=new StringTokenizer(ans, ";;");
                    while(st.hasMoreTokens())
                    {
                        StringTokenizer st1=new StringTokenizer(st.nextToken(), "$");
                        String photo=st1.nextToken();
                        String caption=st1.nextToken();
                        System.out.println(photo+",,"+caption);
                        JLabel lb=new JLabel();
                        lb.setBounds(x, y, 70,  70);
                        jp2.add(lb);
                        jp2.repaint();
                        x+=90;
                        JLabel lb1=new JLabel();
                        lb1.setText(email);
                        lb1.setForeground(Color.WHITE);
                        lb1.setBounds(x1, y1, 70, 20);
                        x1+=90;
                        jp2.add(lb1);
                        ImageIcon ic=new ImageIcon(photo);
                        Image ic1=ic.getImage().getScaledInstance(lb.getWidth(), lb.getHeight(), Image.SCALE_SMOOTH);
                        ImageIcon ic2=new ImageIcon(ic1);
                        lb.setIcon(ic2);
                        
                         lb.addMouseListener(new MouseAdapter()
                        {
                                @Override
                                public void mouseClicked(MouseEvent e)
                                {
                                    show_story obj=new show_story(photo,caption);
                                    obj.setVisible(true);
                                }
                        }
                        );
                        
                        
                        
                        
                        
                        

     
                    }    
                    
                }    
                
               
            }    
           catch(Exception ex)
           {
               ex.printStackTrace();
           }    
                
              
        
        
    }        
    
    
    
    
    
    void show_post()
    {
        
        
        int x=120;
        int y=10;
        jp4.removeAll();
        
        String ans=MyClient.all_users();
        StringTokenizer st=new StringTokenizer(ans,";;");
         while(st.hasMoreTokens())
        {
            String ans1=st.nextToken();
            StringTokenizer st2=new StringTokenizer(ans1, "$");
            String email=st2.nextToken();
            String photo=st2.nextToken();
            try
            {
                ResultSet rs1=DBloader.executeSql("select * from followers where follow_by='"+Global.email+"' and follow_to='"+email+"'");
         
                if(rs1.next())
                {
                    String ans2=MyClient.show_post(email);
                    
                    StringTokenizer st3=new StringTokenizer(ans2, ";;");
                    while(st3.hasMoreTokens())
                    {
                       // jp3.removeAll();
                        StringTokenizer st4=new StringTokenizer(st3.nextToken(), "$");
                        String photo1=st4.nextToken();
                        String caption=st4.nextToken();
                        String postid=st4.nextToken();
                        post_design obj=new post_design();
                        
                        ResultSet rs=DBloader.executeSql("select * from likepost where user_email='"+Global.email+"' and post_id='"+postid+"' ");
                         if(rs.next())
                            {
                            ImageIcon ica=new ImageIcon("/Users/vasu/Desktop/photos/heart like.png");
                            Image icb=ica.getImage().getScaledInstance(obj.likebt.getWidth(), obj.likebt.getHeight(), Image.SCALE_SMOOTH);
                            ImageIcon icc=new ImageIcon(icb);
                            obj.likebt.setIcon(icc);
                                 //obj.likebt.setText("Liked");
                            } 
                         else
                         {
                            ImageIcon icd=new ImageIcon("/Users/vasu/Desktop/photos/heart unlike.png");
                            Image ice=icd.getImage().getScaledInstance(obj.likebt.getWidth(), obj.likebt.getHeight(), Image.SCALE_SMOOTH);
                            ImageIcon icf=new ImageIcon(ice);
                            obj.likebt.setIcon(icf); 
                            //obj.likebt.setText("Like");
                         }
                                    
                        
                        
                        
                        
                        
                        
                        obj.likebt.addActionListener(new ActionListener() {
                            @Override
                            public void actionPerformed(ActionEvent e) 
                            {
                                try
                                {
                                 ResultSet rs=DBloader.executeSql("select * from likepost where user_email='"+Global.email+"' and post_id='"+postid+"' ");
                                 
                                 if(rs.next())
                                 {
                                     rs.deleteRow();
                                     ImageIcon ic5=new ImageIcon("/Users/vasu/Desktop/photos/heart unlike.png");
                                     Image ic6=ic5.getImage().getScaledInstance(obj.likebt.getWidth(), obj.likebt.getHeight(), Image.SCALE_SMOOTH);
                                     ImageIcon ic7=new ImageIcon(ic6);
                                     obj.likebt.setIcon(ic7);
                                     //obj.likebt.setText("Like");
                                 }
                                 else
                                 {
                                     rs.moveToInsertRow();
                                     rs.updateString("user_email", Global.email);
                                     rs.updateString("post_id", postid);
                                     rs.insertRow();
                                     ImageIcon ic9=new ImageIcon("/Users/vasu/Desktop/photos/heart like.png");
                                     Image ic10=ic9.getImage().getScaledInstance(obj.likebt.getWidth(), obj.likebt.getHeight(), Image.SCALE_SMOOTH);
                                     ImageIcon ic11=new ImageIcon(ic10);
                                     obj.likebt.setIcon(ic11);
                                    // obj.likebt.setText("Liked");

                                 }    
 
                                }
                                catch(Exception ex)
                                {
                                    ex.printStackTrace();
                                }    
                            }
                        });
                        
                       obj.email.setText(email);
                       ImageIcon ic3=new ImageIcon(photo);
                       Image ic4=ic3.getImage().getScaledInstance(obj.userphoto.getWidth(), obj.userphoto.getHeight(), Image.SCALE_SMOOTH);
                       ImageIcon ic5=new ImageIcon(ic4);
                       obj.userphoto.setIcon(ic5);
                       
                       obj.captionlb.setText(email+"::  "+caption);
                       ImageIcon ic=new ImageIcon(photo1);
                       Image ic1=ic.getImage().getScaledInstance(obj.post.getWidth(), obj.post.getHeight(), Image.SCALE_SMOOTH);
                       ImageIcon ic2=new ImageIcon(ic1);
                       obj.post.setIcon(ic2);
                       obj.setBounds(x,y,552,485);
                       jp4.add(obj);
                       obj.repaint();
                       jp4.repaint();
                       jp4.revalidate();
                       y+=500;
     
                     }
                    
                    jp4.setPreferredSize(new Dimension(450,552+y));

                }
            }
            
            catch(Exception ex)
            {
                ex.printStackTrace();
            }
            
        }
    }        
    
    
    void all_users()
    {
        String ans=MyClient.all_users();
        int x=10;
        int y=10;
        StringTokenizer st=new StringTokenizer(ans, ";;");
        int count = st.countTokens();
        while(st.hasMoreTokens())
        {
            String ans1=st.nextToken();
            StringTokenizer st2=new StringTokenizer(ans1, "$");
            String email=st2.nextToken();
            String photo=st2.nextToken();
           
            user_design obj=new user_design();
            
             try 
            {
                ResultSet rs1=DBloader.executeSql("select * from followers where follow_by='"+Global.email+"' and follow_to='"+email+"' ");
                if(rs1.next())
                {
                    obj.followbt.setText("Followed");
                } 
                else
                {
                    obj.followbt.setText("Follow");
                }
                                     
              
            } 
             
            catch (Exception ex) 
            {
                ex.printStackTrace();
            }
             
             
             
             
            obj.followbt.addActionListener(new ActionListener() 
            {
                @Override
                public void actionPerformed(ActionEvent e) {
                    String type=obj.followbt.getText();
                    
                    
                  if(type.equals("Followed"))
                  {
                     
                      try 
                      {
                         ResultSet rs=DBloader.executeSql("select * from followers where follow_by='"+Global.email+"' and follow_to='"+email+"'");  
                          
                             if(rs.next())
                            {
                                rs.deleteRow();
                                obj.followbt.setText("Follow");
                                Homepage obj=new Homepage();
                                dispose();
                            }
                      } 
                      catch (Exception ex) 
                      {
                          ex.printStackTrace();
                      }
                  }
                  
                  
                  else
                  {
                      
                      try 
                      {
                           ResultSet rs=DBloader.executeSql("select * from followers where follow_by='"+Global.email+"' and follow_to='"+email+"'");
                          rs.moveToInsertRow();
                          rs.updateString("follow_by", Global.email);
                          rs.updateString("follow_to", email);
                          rs.insertRow();
                          obj.followbt.setText("Followed");
                          
                          Homepage obj=new Homepage();
                          dispose();
                          
                      } 
                      catch (Exception ex) 
                      {
                          
                          ex.printStackTrace();
                      }
                      
                  }
                    
                }
            });
            
            
            
            
      
             obj.seeprofilebt.addActionListener(new ActionListener() 
            {
                @Override
                public void actionPerformed(ActionEvent e) {
                    
                  other_user_profile obj5= new other_user_profile(email);
                    
                }
            });
      
      
            
            
            
            obj.emaillabel.setText(email);
            ImageIcon ic=new ImageIcon(photo);
            Image ic1=ic.getImage().getScaledInstance(obj.photolabel.getWidth(), obj.photolabel.getHeight(), Image.SCALE_SMOOTH);
            ImageIcon ic2=new ImageIcon(ic1);
            obj.photolabel.setIcon(ic2);
            obj.setBounds(x, y, 330, 160);
            y+=175;
            jp3.add(obj);
            obj.repaint();
            jp3.repaint();
           jp3.revalidate();
            
        }   
      
        jp3.setPreferredSize(new Dimension(300, 180+y));
        
        
    }       

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jp1 = new javax.swing.JPanel();
        addpostbt = new javax.swing.JButton();
        addstorybt = new javax.swing.JButton();
        label1 = new javax.swing.JLabel();
        welcomelb = new javax.swing.JLabel();
        myprofile = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        logoutbt = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jp2 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jp3 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jp4 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jp1.setBackground(new java.awt.Color(0, 0, 0));
        jp1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jp1.setLayout(null);

        addpostbt.setFont(new java.awt.Font("Helvetica Neue", 0, 18)); // NOI18N
        addpostbt.setText("Add Post");
        addpostbt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addpostbtActionPerformed(evt);
            }
        });
        jp1.add(addpostbt);
        addpostbt.setBounds(50, 210, 150, 40);

        addstorybt.setFont(new java.awt.Font("Helvetica Neue", 0, 18)); // NOI18N
        addstorybt.setText("Add Story");
        addstorybt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addstorybtActionPerformed(evt);
            }
        });
        jp1.add(addstorybt);
        addstorybt.setBounds(50, 280, 150, 40);

        label1.setFont(new java.awt.Font("Helvetica Neue", 0, 18)); // NOI18N
        label1.setForeground(new java.awt.Color(255, 255, 255));
        label1.setText("Welcome");
        jp1.add(label1);
        label1.setBounds(80, 690, 76, 23);

        welcomelb.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        welcomelb.setForeground(new java.awt.Color(255, 255, 255));
        jp1.add(welcomelb);
        welcomelb.setBounds(20, 730, 220, 40);

        myprofile.setFont(new java.awt.Font("Helvetica Neue", 0, 18)); // NOI18N
        myprofile.setText("My Profile");
        myprofile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                myprofileActionPerformed(evt);
            }
        });
        jp1.add(myprofile);
        myprofile.setBounds(50, 140, 150, 40);

        jLabel1.setFont(new java.awt.Font("Skia", 3, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 0, 153));
        jLabel1.setText("INSTAGRAM");
        jp1.add(jLabel1);
        jLabel1.setBounds(20, 30, 220, 50);

        jButton1.setFont(new java.awt.Font("Helvetica Neue", 1, 13)); // NOI18N
        jButton1.setText("Change Password");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jp1.add(jButton1);
        jButton1.setBounds(50, 350, 150, 40);

        logoutbt.setFont(new java.awt.Font("Helvetica Neue", 1, 14)); // NOI18N
        logoutbt.setText("Logout");
        logoutbt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutbtActionPerformed(evt);
            }
        });
        jp1.add(logoutbt);
        logoutbt.setBounds(50, 420, 150, 40);

        jButton2.setText("Refresh Page");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jp1.add(jButton2);
        jButton2.setBounds(50, 620, 140, 40);

        jScrollPane1.setViewportView(jp1);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(0, 0, 260, 830);

        jp2.setBackground(new java.awt.Color(51, 0, 102));
        jp2.setLayout(null);
        jScrollPane2.setViewportView(jp2);

        getContentPane().add(jScrollPane2);
        jScrollPane2.setBounds(260, 0, 810, 120);

        jScrollPane3.setPreferredSize(new java.awt.Dimension(378, 800));

        jp3.setBackground(new java.awt.Color(0, 0, 0));
        jp3.setPreferredSize(new java.awt.Dimension(378, 798));
        jp3.setLayout(null);
        jScrollPane3.setViewportView(jp3);

        getContentPane().add(jScrollPane3);
        jScrollPane3.setBounds(1070, 0, 370, 830);

        jp4.setBackground(new java.awt.Color(0, 0, 0));
        jp4.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(153, 0, 153), 10, true));
        jp4.setLayout(null);
        jScrollPane4.setViewportView(jp4);

        getContentPane().add(jScrollPane4);
        jScrollPane4.setBounds(260, 120, 810, 710);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void addpostbtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addpostbtActionPerformed
        // TODO add your handling code here:

        Add_Post obj =new Add_Post();
    }//GEN-LAST:event_addpostbtActionPerformed

    private void addstorybtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addstorybtActionPerformed
        // TODO add your handling code here:
        Add_Story obj=new Add_Story();
    }//GEN-LAST:event_addstorybtActionPerformed

    private void myprofileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_myprofileActionPerformed
        // TODO add your handling code here:
        
        user_profile obj=new user_profile();
    }//GEN-LAST:event_myprofileActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        change_password obj=new change_password();

    }//GEN-LAST:event_jButton1ActionPerformed

    private void logoutbtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutbtActionPerformed
        // TODO add your handling code here:
        int ans = JOptionPane.showConfirmDialog(this,"Are you Sure u want to Logout ??","Logout Confirmation",JOptionPane.YES_NO_OPTION); 
            
            if(ans==JOptionPane.YES_OPTION)
            {
                dispose();
                Login obj=new Login();
            }
            
        
        
    }//GEN-LAST:event_logoutbtActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        Homepage obj=new Homepage();
        dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Homepage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Homepage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Homepage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Homepage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Homepage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addpostbt;
    private javax.swing.JButton addstorybt;
    private javax.swing.JButton jButton1;
    public javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JPanel jp1;
    private javax.swing.JPanel jp2;
    private javax.swing.JPanel jp3;
    private javax.swing.JPanel jp4;
    private javax.swing.JLabel label1;
    private javax.swing.JButton logoutbt;
    private javax.swing.JButton myprofile;
    private javax.swing.JLabel welcomelb;
    // End of variables declaration//GEN-END:variables
}
