
package mycodes;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import java.io.File;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;


public class MyClient 

{
    public static String userSignup(String name,String email,String password,String contact,String gender,File photo)
    {
      String ans="";
        try {
            HttpResponse<String> res=Unirest.post("http://localhost:9000/user_signup")
                    .queryString("name", name)
                    .queryString("email", email)
                    .queryString("gender", gender)
                    .queryString("contact", contact)
                    .queryString("password", password)
                    .field("photo", photo)
                    
                    .asString();
            ans=res.getBody();
        } 
        catch (UnirestException ex) 
        {
          ex.printStackTrace();
        }
        
        
        return ans;  
    }
    
    
    public static String userLogin(String email,String password)
    {
        String ans="";
         try {
            HttpResponse<String> res=Unirest.get("http://localhost:9000/user_Login")
                    
                    .queryString("email", email)
                    .queryString("password", password)
                    .asString();
            ans=res.getBody();
        } 
        catch (UnirestException ex) 
        {
          ex.printStackTrace();
        }
        
        
        return ans;  
        
    }
    
    
    public static String all_users()
    {
        String ans="";
        try 
        {
            HttpResponse<String> res=Unirest.get("http://localhost:9000/all_users").asString();
            ans=res.getBody();
        } 
        catch (UnirestException ex) 
        {
          ex.printStackTrace();
        }
        
        
        return ans; 
    }   
    
    
    
    public static String addPost(String email,String caption,File photo)
    {
      String ans="";
        try {
            HttpResponse<String> res=Unirest.post("http://localhost:9000/addPost")
                    .queryString("email", email)
                    .queryString("caption", caption)
                    .field("photo", photo)
                    
                    .asString();
            ans=res.getBody();
        } 
        catch (UnirestException ex) 
        {
          ex.printStackTrace();
        }
        
        
        return ans;  
    }
    
    
    
    public static String show_post(String email)
    {
      String ans="";
        try {
            HttpResponse<String> res=Unirest.get("http://localhost:9000/show_post")
                    .queryString("email", email)
             
                .asString();
            ans=res.getBody();
        } 
        catch (UnirestException ex) 
        {
          ex.printStackTrace();
        }
        
        
        return ans;  
    }
    
    
     public static String addStory(String email,String caption,File photo)
    {
      String ans="";
        try {
            HttpResponse<String> res=Unirest.post("http://localhost:9000/addStory")
                    .queryString("email", email)
                    .queryString("caption", caption)
                    .field("photo", photo)
                    
                    .asString();
            ans=res.getBody();
        } 
        catch (UnirestException ex) 
        {
          ex.printStackTrace();
        }
        
        
        return ans;  
    }
     
     
      
    public static String show_story(String email)
    {
      String ans="";
        try {
            HttpResponse<String> res=Unirest.get("http://localhost:9000/show_story")
                    .queryString("email", email)
             
                .asString();
            ans=res.getBody();
        } 
        catch (UnirestException ex) 
        {
          ex.printStackTrace();
        }
        
        
        return ans;  
    }
    
    
    
    public static String user_posts()
    {
        String ans="";
        try 
        {
            HttpResponse<String> res=Unirest.get("http://localhost:9000/user_posts").asString();
            ans=res.getBody();
        } 
        catch (Exception ex) 
        {
          ex.printStackTrace();
        }
        
        
        return ans; 
    }   
    
    
    
    public static String other_user_posts(String email)
    {
      String ans="";
        try {
            HttpResponse<String> res=Unirest.get("http://localhost:9000/other_user_posts")
                    .queryString("email", email)
             
                .asString();
            ans=res.getBody();
        } 
        catch (UnirestException ex) 
        {
          ex.printStackTrace();
        }
        
        
        return ans;  
    }
    
    
    
    
    
    
    
     public static String editprofilewithphotoselected(String name,String contact,String gender,File photo)
    {
      String ans="";
        try {
            HttpResponse<String> res=Unirest.post("http://localhost:9000/editprofilewithphotoselected")
                    .queryString("name", name)
                    
                    .queryString("gender", gender)
                    .queryString("contact", contact)
                    
                    .field("photo", photo)
                    
                    .asString();
            ans=res.getBody();
        } 
        catch (UnirestException ex) 
        {
          ex.printStackTrace();
        }
        
        
        return ans;  
    }
    
    
     public static String editprofilewithoutphotoselected(String name,String contact,String gender)
    {
      String ans="";
        try {
            HttpResponse<String> res=Unirest.get("http://localhost:9000/editprofilewithoutphotoselected")
                    .queryString("name", name)
                    
                    .queryString("gender", gender)
                    .queryString("contact", contact)
                    
                    
                    .asString();
            ans=res.getBody();
        } 
        catch (UnirestException ex) 
        {
          ex.printStackTrace();
        }
        
        
        return ans;  
    } 
    
    
    
    
}
